using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace CombatRally.EditorTools
{
    /// Генерирует прототип-сцену, префабы машин и сенсорный UI из кода
    /// (меню Combat Rally -> Build Prototype Scene; в CI вызывается автоматически).
    public static class PrototypeBuilder
    {
        public const string ScenePath = "Assets/Scenes/Track01.unity";
        const string PrefabDir = "Assets/Prefabs";
        const string MatDir = "Assets/Prefabs/Materials";

        [MenuItem("Combat Rally/Build Prototype Scene")]
        public static void EnsureScene()
        {
            Directory.CreateDirectory("Assets/Scenes");
            Directory.CreateDirectory(MatDir);
            AssetDatabase.Refresh();

            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            foreach (var c in Object.FindObjectsOfType<Camera>()) Object.DestroyImmediate(c.gameObject);

            var dirt = Mat("Dirt", new Color(0.45f, 0.32f, 0.2f));
            var wall = Mat("Wall", new Color(0.35f, 0.35f, 0.38f));
            var blue = Mat("CarBlue", new Color(0.15f, 0.35f, 0.9f));
            var red = Mat("CarRed", new Color(0.85f, 0.15f, 0.15f));

            // Трасса
            Box("Ground", null, new Vector3(0, -0.5f, 700), new Vector3(60, 1, 1500), dirt, true);
            Box("WallL", null, new Vector3(-30.5f, 1, 700), new Vector3(1, 3, 1500), wall, true);
            Box("WallR", null, new Vector3(30.5f, 1, 700), new Vector3(1, 3, 1500), wall, true);

            var wpRoot = new GameObject("Waypoints");
            var wps = new Transform[28];
            for (int i = 0; i < wps.Length; i++)
            {
                var w = new GameObject("WP_" + i).transform;
                w.SetParent(wpRoot.transform);
                w.position = new Vector3(Mathf.Sin(i * 0.55f) * 8f, 0.5f, 20f + i * 50f);
                wps[i] = w;
            }

            // Ввод
            new GameObject("Input").AddComponent<GameInputRouter>();

            // Игрок
            var playerPrefab = SavePrefab(BuildCar("PlayerCar", blue, true), "PlayerCar");
            var player = (GameObject)PrefabUtility.InstantiatePrefab(playerPrefab);
            player.transform.position = new Vector3(0, 0.6f, 0);

            // Соперники
            var rivalPrefab = SavePrefab(BuildCar("RivalCar", red, false), "RivalCar");
            float[] xs = { -6f, 6f, 0f };
            for (int i = 0; i < 3; i++)
            {
                var r = (GameObject)PrefabUtility.InstantiatePrefab(rivalPrefab);
                r.name = "Rival_" + i;
                r.transform.position = new Vector3(xs[i], 0.6f, 12f + i * 12f);
                var ai = r.GetComponent<RivalAI>();
                ai.waypoints = wps; ai.target = player.transform; ai.aggression = 0.4f + 0.25f * i;
            }

            BuildCanvas(player.GetComponentInChildren<ShotgunController>());

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
        }

        // ---------- машины ----------
        static GameObject BuildCar(string name, Material paint, bool player)
        {
            var root = new GameObject(name);
            Box("Body", root.transform, new Vector3(0, 0.55f, 0), new Vector3(2f, 0.8f, 4.2f), paint, false);
            if (!player) Box("Cabin", root.transform, new Vector3(0, 1.15f, -0.3f), new Vector3(1.7f, 0.6f, 2f), paint, false);

            var col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0, 0.6f, 0); col.size = new Vector3(2f, 1.1f, 4.2f);

            var rb = root.AddComponent<Rigidbody>();
            rb.mass = 1000f; rb.drag = 0.05f; rb.angularDrag = 1.2f;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

            var motor = root.AddComponent<CarMotor>();
            root.AddComponent<Health>();

            if (player)
            {
                var camGO = new GameObject("PlayerCamera") { tag = "MainCamera" };
                camGO.transform.SetParent(root.transform, false);
                camGO.transform.localPosition = new Vector3(-0.35f, 1.25f, 0.2f);
                var cam = camGO.AddComponent<Camera>(); cam.fieldOfView = 78f; cam.nearClipPlane = 0.05f;
                camGO.AddComponent<AudioListener>();

                var hand = new GameObject("HandPivot");
                hand.transform.SetParent(camGO.transform, false);
                hand.transform.localPosition = new Vector3(0.3f, -0.3f, 0.45f);
                Box("Shotgun", hand.transform, new Vector3(0, 0, 0.45f), new Vector3(0.11f, 0.13f, 0.95f), Mat("Steel", new Color(0.12f, 0.12f, 0.14f)), false);
                Box("Hand", hand.transform, new Vector3(0, -0.1f, 0.05f), new Vector3(0.14f, 0.14f, 0.2f), Mat("Skin", new Color(0.85f, 0.65f, 0.5f)), false);
                var muzzle = new GameObject("Muzzle"); muzzle.transform.SetParent(hand.transform, false);
                muzzle.transform.localPosition = new Vector3(0, 0, 0.95f);

                var gun = camGO.AddComponent<ShotgunController>();
                gun.handPivot = hand.transform; gun.muzzle = muzzle.transform;
                gun.cameraTransform = camGO.transform; gun.car = motor;

                root.AddComponent<PlayerCarController>().weapon = gun;
            }
            else
            {
                motor.maxSpeed = 32f;
                root.AddComponent<RivalAI>();
                root.GetComponent<Health>().destroyOnDeath = true;
            }
            return root;
        }

        static GameObject SavePrefab(GameObject root, string name)
        {
            var prefab = PrefabUtility.SaveAsPrefabAsset(root, $"{PrefabDir}/{name}.prefab");
            Object.DestroyImmediate(root);
            return prefab;
        }

        // ---------- UI ----------
        static void BuildCanvas(ShotgunController weapon)
        {
            var canvasGO = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasGO.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGO.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080); scaler.matchWidthOrHeight = 0.5f;

            var esGO = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
            esGO.GetComponent<InputSystemUIInputModule>().AssignDefaultActions();

            var knob = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Knob.psd");
            var touch = Panel("TouchControls", canvasGO.transform, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero, Color.clear);
            var trt = (RectTransform)touch.transform; trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one; trt.offsetMin = trt.offsetMax = Vector2.zero;
            touch.GetComponent<Image>().raycastTarget = false;

            // Зона оружия (первой => под кнопками)
            var zone = Panel("WeaponZone", touch.transform, new Vector2(1, 0.5f), new Vector2(-360, 120), new Vector2(600, 500), new Color(1, 1, 1, 0.06f));
            zone.AddComponent<TouchWeaponGestures>(); Label(zone.transform, "TAP = FIRE\nSWIPE v = OPEN / ^ = CLOSE\nDRAG = AIM", 28);

            var wheel = Panel("Wheel", touch.transform, new Vector2(0, 0), new Vector2(260, 260), new Vector2(380, 380), new Color(1, 1, 1, 0.25f), knob);
            wheel.AddComponent<TouchSteeringWheel>();
            Panel("WheelMark", wheel.transform, new Vector2(0.5f, 1f), new Vector2(0, -30), new Vector2(50, 50), new Color(1, 0.3f, 0.2f, 0.9f), knob);

            Btn(touch.transform, "Gas", "GAS", TouchButtonKind.Throttle, new Vector2(1, 0), new Vector2(-170, 170), 240, knob);
            Btn(touch.transform, "Brake", "BRAKE", TouchButtonKind.Brake, new Vector2(1, 0), new Vector2(-440, 130), 190, knob);
            Btn(touch.transform, "Drift", "DRIFT", TouchButtonKind.Handbrake, new Vector2(1, 0), new Vector2(-440, 350), 160, knob);
            Btn(touch.transform, "Open", "OPEN", TouchButtonKind.ReloadOpen, new Vector2(1, 1), new Vector2(-110, -110), 180, knob);
            Btn(touch.transform, "Load", "LOAD", TouchButtonKind.ReloadInsert, new Vector2(1, 1), new Vector2(-320, -110), 180, knob);
            Btn(touch.transform, "Close", "CLOSE", TouchButtonKind.ReloadClose, new Vector2(1, 1), new Vector2(-530, -110), 180, knob);

            var ammo = Panel("Ammo", canvasGO.transform, new Vector2(0, 1), new Vector2(330, -50), new Vector2(620, 70), Color.clear);
            var ammoText = Label(ammo.transform, "", 34); ammoText.alignment = TextAnchor.MiddleLeft;
            var hud = ammo.AddComponent<AmmoHUD>(); hud.label = ammoText; hud.weapon = weapon;

            var sw = canvasGO.AddComponent<PromptIconSwitcher>();
            sw.touchControlsRoot = touch;
            sw.prompts = new PromptEntry[0]; // сюда назначаются иконки Xbox/PS/Touch/Keyboard
        }

        static void Btn(Transform parent, string name, string text, TouchButtonKind kind, Vector2 anchor, Vector2 pos, float size, Sprite knob)
        {
            var b = Panel(name, parent, anchor, pos, new Vector2(size, size), new Color(1, 1, 1, 0.3f), knob);
            b.AddComponent<TouchHoldButton>().kind = kind;
            Label(b.transform, text, 36);
        }

        static GameObject Panel(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color color, Sprite sprite = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = anchor; rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos; rt.sizeDelta = size;
            var img = go.GetComponent<Image>(); img.color = color; if (sprite != null) img.sprite = sprite;
            return go;
        }

        static Text Label(Transform parent, string text, int size)
        {
            var go = new GameObject("Label", typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero;
            var t = go.GetComponent<Text>();
            t.text = text; t.alignment = TextAnchor.MiddleCenter; t.fontSize = size; t.color = Color.white; t.raycastTarget = false;
            t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            return t;
        }

        // ---------- утилиты ----------
        static Material Mat(string name, Color c)
        {
            string path = $"{MatDir}/{name}.mat";
            var m = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (m == null) { m = new Material(Shader.Find("Standard")); AssetDatabase.CreateAsset(m, path); }
            m.color = c; EditorUtility.SetDirty(m);
            return m;
        }

        static GameObject Box(string name, Transform parent, Vector3 pos, Vector3 scale, Material mat, bool keepCollider)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            if (parent != null) go.transform.SetParent(parent, false);
            go.transform.localPosition = pos; go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            if (!keepCollider) Object.DestroyImmediate(go.GetComponent<Collider>());
            return go;
        }
    }
}
