using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

/// Точка входа для CI: -executeMethod BuildScript.BuildAndroid
public static class BuildScript
{
    static string Arg(string name)
    {
        var a = Environment.GetCommandLineArgs();
        for (int i = 0; i < a.Length - 1; i++) if (a[i] == name) return a[i + 1];
        return null;
    }

    public static void BuildAndroid()
    {
        CombatRally.EditorTools.PrototypeBuilder.EnsureScene();

        PlayerSettings.companyName = "CombatRally";
        PlayerSettings.productName = "Combat Rally Prototype";
        PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.combatrally.prototype");
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        if (int.TryParse(Arg("-androidVersionCode"), out int vc)) PlayerSettings.Android.bundleVersionCode = vc;
        EditorUserBuildSettings.buildAppBundle = false;            // APK, не AAB

        string outPath = Arg("-customBuildPath") ?? "build/Android/CombatRally.apk";
        Directory.CreateDirectory(Path.GetDirectoryName(outPath) ?? ".");

        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
        {
            scenes = new[] { CombatRally.EditorTools.PrototypeBuilder.ScenePath },
            locationPathName = outPath,
            target = BuildTarget.Android,
            options = BuildOptions.None
        });

        Debug.Log("Build result: " + report.summary.result + " -> " + outPath);
        EditorApplication.Exit(report.summary.result == BuildResult.Succeeded ? 0 : 1);
    }
}
