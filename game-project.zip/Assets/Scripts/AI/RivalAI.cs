using UnityEngine;

namespace CombatRally
{
    /// Соперник: едет по вейпойнтам, обгоняет игрока по свободной полосе,
    /// периодически таранит и отстреливается (чаще — после попаданий по нему).
    [RequireComponent(typeof(CarMotor))]
    public class RivalAI : MonoBehaviour
    {
        public enum Mode { Follow, Overtake, Ram, Recover }

        public Transform[] waypoints;
        public Transform target;                         // игрок
        [Range(0f, 1f)] public float aggression = 0.6f;

        [Header("Driving")]
        public float waypointReach = 14f;
        public float cruiseThrottle = 0.95f;

        [Header("Overtake")]
        public float overtakeDistance = 22f;
        public float laneOffset = 4f;

        [Header("Ram")]
        public float ramDistance = 9f;
        public float ramCooldown = 6f;
        public float ramDuration = 2.5f;

        [Header("Shooting")]
        public float shootRange = 30f;
        public float shootInterval = 1.4f;
        public float shootDamage = 6f;
        public float shootConeAngle = 22f;
        public float retaliateConeAngle = 60f;

        public Mode Current { get; private set; }

        CarMotor motor;
        Health health;
        int idx;
        float ramActive, ramCd, shootTimer, retaliateTimer, stuckTimer, recoverTimer;

        void Awake()
        {
            motor = GetComponent<CarMotor>();
            health = GetComponent<Health>();
            if (health != null)
            {
                health.OnDamaged += src => retaliateTimer = 4f;
                health.OnDied += () => { motor.ZeroInputs(); motor.Brake = 1f; enabled = false; };
            }
        }

        void Update()
        {
            if (waypoints == null || waypoints.Length == 0) return;
            float dt = Time.deltaTime;
            ramActive -= dt; ramCd -= dt; shootTimer -= dt; retaliateTimer -= dt;

            Transform wp = waypoints[idx];
            Vector3 flat = wp.position - transform.position; flat.y = 0f;
            if (flat.magnitude < waypointReach && idx < waypoints.Length - 1) idx++;

            Vector3 desired = wp.position;
            Mode mode = Mode.Follow;

            if (target != null)
            {
                Vector3 rel = transform.InverseTransformPoint(target.position);
                float dist = rel.magnitude;

                if (ramActive > 0f) mode = Mode.Ram;
                else if (dist < ramDistance && ramCd <= 0f && Random.value < aggression * dt * 3f)
                { ramActive = ramDuration; ramCd = ramCooldown; mode = Mode.Ram; }
                else if (rel.z > 0f && rel.z < overtakeDistance && Mathf.Abs(rel.x) < 3f)
                    mode = Mode.Overtake;

                if (mode == Mode.Ram) desired = target.position;
                else if (mode == Mode.Overtake) desired = wp.position + transform.right * (rel.x >= 0f ? -laneOffset : laneOffset);

                TryShoot(rel, dist);
            }

            // Анти-застревание: если стоим — даём задний ход
            if (Time.timeSinceLevelLoad > 4f && motor.Body.velocity.magnitude < 1.5f) stuckTimer += dt; else stuckTimer = 0f;
            if (stuckTimer > 2f) { recoverTimer = 1.2f; stuckTimer = 0f; }
            if (recoverTimer > 0f)
            {
                recoverTimer -= dt;
                Current = Mode.Recover;
                motor.Throttle = 0f; motor.Brake = 1f; motor.Steer = -Mathf.Sign(motor.Steer == 0f ? 1f : motor.Steer);
                return;
            }

            Current = mode;
            Drive(desired, mode);
        }

        void Drive(Vector3 desired, Mode mode)
        {
            Vector3 local = transform.InverseTransformPoint(desired);
            float angle = Mathf.Atan2(local.x, local.z);
            float turn = Mathf.Abs(angle);

            motor.Steer = Mathf.Clamp(angle * 1.8f, -1f, 1f);
            motor.Throttle = Mathf.Clamp01((mode == Mode.Ram ? 1f : cruiseThrottle) - turn * 0.35f);
            motor.Brake = (turn > 1.0f && motor.ForwardSpeed > 15f) ? 0.6f : 0f;
            motor.Handbrake = turn > 1.2f && motor.ForwardSpeed > 14f;
        }

        void TryShoot(Vector3 rel, float dist)
        {
            if (shootTimer > 0f || dist > shootRange) return;
            float cone = retaliateTimer > 0f ? retaliateConeAngle : shootConeAngle;
            if (Vector3.Angle(Vector3.forward, rel) > cone) return;

            shootTimer = shootInterval * Random.Range(0.8f, 1.3f);
            Vector3 origin = transform.position + transform.up * 0.8f + transform.forward * 1.5f;
            Vector3 dir = (target.position + Vector3.up * 0.7f - origin).normalized;
            dir = (dir + Random.insideUnitSphere * 0.08f).normalized;
            if (Physics.Raycast(origin, dir, out RaycastHit hit, shootRange * 1.2f, ~0, QueryTriggerInteraction.Ignore))
            {
                var h = hit.collider.GetComponentInParent<Health>();
                if (h != null && h.gameObject == target.gameObject)
                {
                    h.TakeDamage(shootDamage, hit.point, gameObject);
                    if (hit.rigidbody != null) hit.rigidbody.AddForce(dir * 150f, ForceMode.Impulse);
                }
            }
        }
    }
}
