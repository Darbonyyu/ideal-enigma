using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace CombatRally
{
    public enum ShotgunState { Closed, Opening, Open, Loading, Closing }
    enum Chamber { Empty, Loaded, Spent }

    /// Двуствольный обрез. Ручная перезарядка: Open -> Insert (по 1 патрону) -> Close.
    /// Стрелять можно только при закрытом стволе. Положение руки = правый стик / drag по экрану.
    public class ShotgunController : MonoBehaviour
    {
        public const int Chambers = 2;

        [Header("Refs")]
        public Transform handPivot;
        public Transform muzzle;
        public Transform cameraTransform;
        public CarMotor car;

        [Header("Ballistics")]
        public int pelletsPerShot = 9;
        public float spreadAngle = 4.5f;
        public float range = 35f;
        public float damagePerPellet = 8f;
        public LayerMask hitMask = ~0;

        [Header("Ammo")]
        public int reserveShells = 24;

        [Header("Timings (sec)")]
        public float openTime = 0.35f;
        public float loadTime = 0.45f;
        public float closeTime = 0.30f;
        public float fireCooldown = 0.15f;

        [Header("Recoil")]
        public float carRecoilImpulse = 700f;
        public float carYawKick = 250f;
        public float handKickDegrees = 9f;
        public float kickRecovery = 40f;
        public float rumbleTime = 0.12f;

        [Header("Hand / aim")]
        public float aimYawRange = 28f;
        public float aimPitchRange = 18f;
        public float poseSmoothing = 14f;

        public ShotgunState State { get; private set; } = ShotgunState.Closed;
        public bool IsBusy => State != ShotgunState.Closed;
        public int LoadedShells { get { int n = 0; foreach (var c in chambers) if (c == Chamber.Loaded) n++; return n; } }

        public event Action<int, int, ShotgunState> OnStatusChanged;
        public event Action OnShot;
        public event Action OnDryFire;

        readonly Chamber[] chambers = { Chamber.Loaded, Chamber.Loaded };
        static readonly RaycastHit[] hitBuffer = new RaycastHit[24];
        GameInputRouter router;
        Vector3 basePos;
        float timer, cooldown, kick, rumbleTimer;

        void Start()
        {
            router = GameInputRouter.Instance;
            if (router != null) { router.OnFire += TryFire; router.OnReloadStep += HandleStep; }
            if (handPivot != null) basePos = handPivot.localPosition;
            Notify();
        }

        void OnDestroy()
        {
            if (router != null) { router.OnFire -= TryFire; router.OnReloadStep -= HandleStep; }
        }

        void OnDisable() { Gamepad.current?.SetMotorSpeeds(0f, 0f); }

        // ---------- логика ----------
        void HandleStep(ReloadStep step)
        {
            switch (step)
            {
                case ReloadStep.Open:
                    if (State == ShotgunState.Closed) Begin(ShotgunState.Opening, openTime);
                    break;
                case ReloadStep.Insert:
                    if (State == ShotgunState.Open && reserveShells > 0 && Array.IndexOf(chambers, Chamber.Empty) >= 0)
                        Begin(ShotgunState.Loading, loadTime);
                    break;
                case ReloadStep.Close:
                    if (State == ShotgunState.Open) Begin(ShotgunState.Closing, closeTime);
                    break;
            }
        }

        void Begin(ShotgunState s, float time) { State = s; timer = time; Notify(); }

        void FinishTransition()
        {
            switch (State)
            {
                case ShotgunState.Opening:
                    for (int i = 0; i < Chambers; i++) if (chambers[i] == Chamber.Spent) chambers[i] = Chamber.Empty; // выброс гильз
                    State = ShotgunState.Open; break;
                case ShotgunState.Loading:
                    int e = Array.IndexOf(chambers, Chamber.Empty);
                    if (e >= 0 && reserveShells > 0) { chambers[e] = Chamber.Loaded; reserveShells--; }
                    State = ShotgunState.Open; break;
                case ShotgunState.Closing:
                    State = ShotgunState.Closed; break;
            }
            Notify();
        }

        void TryFire()
        {
            if (State != ShotgunState.Closed || cooldown > 0f) return;
            int idx = Array.IndexOf(chambers, Chamber.Loaded);
            if (idx < 0) { cooldown = 0.25f; OnDryFire?.Invoke(); return; }

            chambers[idx] = Chamber.Spent;
            cooldown = fireCooldown;
            FirePellets();
            Recoil();
            Notify();
            OnShot?.Invoke();
        }

        void FirePellets()
        {
            GameObject source = car != null ? car.gameObject : gameObject;
            for (int p = 0; p < pelletsPerShot; p++)
            {
                Vector3 dir = Quaternion.AngleAxis(UnityEngine.Random.Range(0f, 360f), muzzle.forward) *
                              (Quaternion.AngleAxis(UnityEngine.Random.Range(0f, spreadAngle), muzzle.up) * muzzle.forward);
                int n = Physics.RaycastNonAlloc(muzzle.position, dir, hitBuffer, range, hitMask, QueryTriggerInteraction.Ignore);
                float best = float.MaxValue; int bi = -1;
                for (int i = 0; i < n; i++)
                {
                    if (car != null && hitBuffer[i].collider.transform.IsChildOf(car.transform)) continue; // не бьём свою машину
                    if (hitBuffer[i].distance < best) { best = hitBuffer[i].distance; bi = i; }
                }
                if (bi < 0) continue;
                var h = hitBuffer[bi];
                var dmg = h.collider.GetComponentInParent<IDamageable>();
                if (dmg != null) dmg.TakeDamage(damagePerPellet * (1f - 0.7f * (h.distance / range)), h.point, source);
            }
        }

        void Recoil()
        {
            if (car != null) car.ApplyRecoil(carRecoilImpulse, UnityEngine.Random.Range(-1f, 1f) * carYawKick);
            kick = handKickDegrees;
            if (router != null && router.IsGamepad && Gamepad.current != null)
            {
                Gamepad.current.SetMotorSpeeds(0.7f, 0.9f);
                rumbleTimer = rumbleTime;
            }
        }

        void Notify() => OnStatusChanged?.Invoke(LoadedShells, reserveShells, State);

        // ---------- анимация руки ----------
        void Update()
        {
            float dt = Time.deltaTime;
            cooldown -= dt;
            kick = Mathf.MoveTowards(kick, 0f, kickRecovery * dt);

            if (rumbleTimer > 0f) { rumbleTimer -= dt; if (rumbleTimer <= 0f) Gamepad.current?.SetMotorSpeeds(0f, 0f); }

            if (State == ShotgunState.Opening || State == ShotgunState.Loading || State == ShotgunState.Closing)
            {
                timer -= dt;
                if (timer <= 0f) FinishTransition();
            }
            UpdateHand(dt);
        }

        void UpdateHand(float dt)
        {
            if (handPivot == null) return;
            Vector2 aim = router != null ? router.Aim : Vector2.zero;

            Vector3 pose; Vector3 offset;
            switch (State)
            {
                case ShotgunState.Opening:
                case ShotgunState.Open:    pose = new Vector3(-35f, 0f, 25f); offset = new Vector3(0f, -0.10f, -0.05f); break;
                case ShotgunState.Loading: pose = new Vector3(-48f, 0f, 32f); offset = new Vector3(-0.05f, -0.16f, -0.08f); break;
                default:                   pose = Vector3.zero;               offset = Vector3.zero; break;
            }

            Quaternion target = Quaternion.Euler(pose.x - aim.y * aimPitchRange - kick, aim.x * aimYawRange, pose.z);
            float k = 1f - Mathf.Exp(-poseSmoothing * dt);
            handPivot.localRotation = Quaternion.Slerp(handPivot.localRotation, target, k);
            handPivot.localPosition = Vector3.Lerp(handPivot.localPosition, basePos + offset - Vector3.forward * (kick * 0.01f), k);

            if (cameraTransform != null) cameraTransform.localRotation = Quaternion.Euler(-kick * 0.35f, 0f, 0f);
        }
    }
}
