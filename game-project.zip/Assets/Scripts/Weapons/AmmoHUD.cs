using UnityEngine;
using UnityEngine.UI;

namespace CombatRally
{
    public class AmmoHUD : MonoBehaviour
    {
        public Text label;
        public ShotgunController weapon;

        void Start()
        {
            if (weapon == null) weapon = FindObjectOfType<ShotgunController>();
            if (weapon == null) return;
            weapon.OnStatusChanged += Refresh;
            Refresh(weapon.LoadedShells, weapon.reserveShells, weapon.State);
        }

        void OnDestroy() { if (weapon != null) weapon.OnStatusChanged -= Refresh; }

        void Refresh(int loaded, int reserve, ShotgunState s)
        {
            if (label != null) label.text = $"SHELLS {loaded}/{ShotgunController.Chambers}   RESERVE {reserve}   {s}";
        }
    }
}
