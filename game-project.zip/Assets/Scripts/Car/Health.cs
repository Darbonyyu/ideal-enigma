using System;
using UnityEngine;

namespace CombatRally
{
    public interface IDamageable { void TakeDamage(float amount, Vector3 point, GameObject source); }

    public class Health : MonoBehaviour, IDamageable
    {
        public float maxHealth = 100f;
        public bool destroyOnDeath = false;
        public float Current { get; private set; }
        public bool IsDead => Current <= 0f;
        public event Action<GameObject> OnDamaged;
        public event Action OnDied;

        void Awake() { Current = maxHealth; }

        public void TakeDamage(float amount, Vector3 point, GameObject source)
        {
            if (IsDead) return;
            Current = Mathf.Max(0f, Current - amount);
            OnDamaged?.Invoke(source);
            if (Current <= 0f)
            {
                OnDied?.Invoke();
                if (destroyOnDeath) Destroy(gameObject, 2f);
            }
        }
    }
}
