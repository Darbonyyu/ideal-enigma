using UnityEngine;

namespace CombatRally
{
    /// Аркадная физика грунтовой гонки: тяга, поперечный "дрейф-грип", yaw-руление, отдача.
    /// Входы пишут PlayerCarController (человек) или RivalAI (бот).
    [RequireComponent(typeof(Rigidbody))]
    public class CarMotor : MonoBehaviour
    {
        [Header("Drive")]
        public float acceleration = 20f;
        public float maxSpeed = 36f;
        public float reverseMaxSpeed = 10f;
        public float brakeDeceleration = 32f;
        public float rollingDrag = 0.4f;
        public float downforce = 6f;

        [Header("Steering")]
        public float maxYawRate = 95f;       // град/с
        public float yawAccel = 10f;         // рад/с^2
        public float fullSteerSpeed = 12f;

        [Header("Dirt grip")]
        public float surfaceGrip = 1f;       // 1 = грунт; меньше = скользче
        public float baseGrip = 5.5f;
        public float driftGrip = 1.3f;
        public float slideBreakSpeed = 6f;

        [Header("Misc")]
        public Vector3 centerOfMassOffset = new Vector3(0, -0.4f, 0);
        public float groundCheckDistance = 1.3f;
        public LayerMask groundMask = ~0;

        [HideInInspector] public float Steer, Throttle, Brake;
        [HideInInspector] public float SteerAuthority = 1f;
        [HideInInspector] public bool Handbrake;

        public Rigidbody Body { get; private set; }
        public bool Grounded { get; private set; }
        public float ForwardSpeed { get; private set; }
        public float LateralSpeed { get; private set; }
        public bool IsDrifting => Grounded && Mathf.Abs(LateralSpeed) > slideBreakSpeed * 0.5f;

        void Awake()
        {
            Body = GetComponent<Rigidbody>();
            Body.centerOfMass = centerOfMassOffset;
        }

        void FixedUpdate()
        {
            Vector3 origin = transform.position + transform.up * 0.5f;
            Grounded = Physics.Raycast(origin, -transform.up, groundCheckDistance, groundMask, QueryTriggerInteraction.Ignore);

            Vector3 vel = Body.velocity;
            ForwardSpeed = Vector3.Dot(vel, transform.forward);
            LateralSpeed = Vector3.Dot(vel, transform.right);
            if (!Grounded) return;

            float dt = Time.fixedDeltaTime;

            // Тяга / тормоз / задний ход
            if (Throttle > 0.01f && ForwardSpeed < maxSpeed)
                Body.AddForce(transform.forward * (Throttle * acceleration), ForceMode.Acceleration);
            if (Brake > 0.01f)
            {
                if (ForwardSpeed > 0.5f)
                    Body.AddForce(-transform.forward * (Brake * brakeDeceleration), ForceMode.Acceleration);
                else if (ForwardSpeed > -reverseMaxSpeed)
                    Body.AddForce(-transform.forward * (Brake * acceleration * 0.6f), ForceMode.Acceleration);
            }
            if (Throttle < 0.01f && Brake < 0.01f)
                Body.AddForce(-transform.forward * (ForwardSpeed * rollingDrag), ForceMode.Acceleration);

            // Боковое сцепление: чем больше скольжение, тем меньше грип. Ручник = занос.
            float slide = Mathf.InverseLerp(slideBreakSpeed, slideBreakSpeed * 2f, Mathf.Abs(LateralSpeed));
            float grip = Handbrake ? driftGrip : Mathf.Lerp(baseGrip, driftGrip * 1.5f, slide);
            grip *= surfaceGrip;
            Body.AddForce(-transform.right * (LateralSpeed * grip), ForceMode.Acceleration);
            Body.AddForce(-transform.up * downforce, ForceMode.Acceleration);

            // Руление через целевую угловую скорость
            float speedFactor = Mathf.Clamp01(Mathf.Abs(ForwardSpeed) / fullSteerSpeed);
            float highSpeedDamp = Mathf.Lerp(1f, 0.6f, Mathf.Abs(ForwardSpeed) / maxSpeed);
            float dirSign = ForwardSpeed >= -0.5f ? 1f : -1f;
            float yawBoost = Handbrake ? 1.35f : 1f;
            float targetYaw = Steer * SteerAuthority * maxYawRate * Mathf.Deg2Rad * speedFactor * highSpeedDamp * dirSign * yawBoost;

            Vector3 lav = transform.InverseTransformDirection(Body.angularVelocity);
            lav.y = Mathf.MoveTowards(lav.y, targetYaw, yawAccel * dt);
            Body.angularVelocity = transform.TransformDirection(lav);
        }

        /// Отдача выстрела: толчок назад + случайный кик по курсу.
        public void ApplyRecoil(float impulse, float yawKick)
        {
            Body.AddForce(-transform.forward * impulse, ForceMode.Impulse);
            Body.AddTorque(transform.up * yawKick, ForceMode.Impulse);
        }

        public void ZeroInputs() { Steer = 0; Throttle = 0; Brake = 0; Handbrake = false; }
    }
}
