using UnityEngine;

namespace CombatRally
{
    /// Читает GameInputRouter (сенсор/геймпад/клавиатура) и кормит CarMotor.
    /// Одна рука: пока дробовик занят перезарядкой, руль слушается хуже.
    [RequireComponent(typeof(CarMotor))]
    public class PlayerCarController : MonoBehaviour
    {
        public ShotgunController weapon;
        [Range(0f, 1f)] public float reloadSteerAuthority = 0.55f;

        CarMotor motor;
        Health health;

        void Awake()
        {
            motor = GetComponent<CarMotor>();
            health = GetComponent<Health>();
        }

        void Update()
        {
            var input = GameInputRouter.Instance;
            if (input == null || (health != null && health.IsDead)) { motor.ZeroInputs(); return; }

            motor.Steer = input.Steer;
            motor.Throttle = input.Throttle;
            motor.Brake = input.Brake;
            motor.Handbrake = input.Handbrake;
            motor.SteerAuthority = (weapon != null && weapon.IsBusy) ? reloadSteerAuthority : 1f;
        }
    }
}
