using UnityEngine;
using UnityEngine.EventSystems;

namespace CombatRally
{
    /// Виртуальный руль: тащим палец по кругу, угол -> Steer.
    public class TouchSteeringWheel : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public float maxAngle = 120f;
        RectTransform rect;

        void Awake() { rect = (RectTransform)transform; }

        public void OnPointerDown(PointerEventData e) => Apply(e);
        public void OnDrag(PointerEventData e) => Apply(e);
        public void OnPointerUp(PointerEventData e) => Release();
        void OnDisable() => Release();

        void Apply(PointerEventData e)
        {
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(rect, e.position, e.pressEventCamera, out Vector2 p)) return;
            float angle = Mathf.Clamp(Mathf.Atan2(p.x, p.y) * Mathf.Rad2Deg, -maxAngle, maxAngle); // + = вправо
            rect.localEulerAngles = new Vector3(0, 0, -angle);
            GameInputRouter.Instance?.SetTouchSteer(angle / maxAngle);
        }

        void Release()
        {
            if (rect != null) rect.localEulerAngles = Vector3.zero;
            GameInputRouter.Instance?.SetTouchSteer(0f);
        }
    }
}
