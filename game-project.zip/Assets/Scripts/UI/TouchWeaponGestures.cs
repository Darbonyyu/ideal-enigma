using UnityEngine;
using UnityEngine.EventSystems;

namespace CombatRally
{
    /// Зона оружия: тап = выстрел, быстрый свайп вниз = открыть казенник, вверх = закрыть,
    /// медленное перетаскивание = позиция руки/прицел.
    public class TouchWeaponGestures : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public float swipeInches = 0.35f;
        public float aimRadiusInches = 0.5f;
        public float swipeMaxTime = 0.3f;
        public float tapMaxTime = 0.25f;

        Vector2 start; float startTime;
        float Dpi => Screen.dpi > 0 ? Screen.dpi : 160f;

        public void OnPointerDown(PointerEventData e) { start = e.position; startTime = Time.unscaledTime; }

        public void OnDrag(PointerEventData e)
        {
            Vector2 d = (e.position - start) / (aimRadiusInches * Dpi);
            GameInputRouter.Instance?.SetTouchAim(new Vector2(d.x, d.y));
        }

        public void OnPointerUp(PointerEventData e)
        {
            var r = GameInputRouter.Instance;
            if (r == null) return;
            r.SetTouchAim(Vector2.zero);

            Vector2 delta = e.position - start;
            float dt = Time.unscaledTime - startTime;
            float swipePx = swipeInches * Dpi;

            if (delta.magnitude < swipePx * 0.3f && dt < tapMaxTime) { r.RaiseFire(); return; }
            if (dt < swipeMaxTime && Mathf.Abs(delta.y) > swipePx && Mathf.Abs(delta.y) > Mathf.Abs(delta.x) * 1.5f)
                r.RaiseReload(delta.y < 0 ? ReloadStep.Open : ReloadStep.Close);
        }

        void OnDisable() { GameInputRouter.Instance?.SetTouchAim(Vector2.zero); }
    }
}
