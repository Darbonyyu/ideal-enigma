using UnityEngine;
using UnityEngine.EventSystems;

namespace CombatRally
{
    public enum TouchButtonKind { Throttle, Brake, Handbrake, Fire, ReloadOpen, ReloadInsert, ReloadClose }

    /// Универсальная экранная кнопка (мультитач работает через InputSystemUIInputModule).
    public class TouchHoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        public TouchButtonKind kind;

        public void OnPointerDown(PointerEventData e)
        {
            var r = GameInputRouter.Instance; if (r == null) return;
            switch (kind)
            {
                case TouchButtonKind.Throttle: r.SetTouchThrottle(1f); break;
                case TouchButtonKind.Brake: r.SetTouchBrake(1f); break;
                case TouchButtonKind.Handbrake: r.SetTouchHandbrake(true); break;
                case TouchButtonKind.Fire: r.RaiseFire(); break;
                case TouchButtonKind.ReloadOpen: r.RaiseReload(ReloadStep.Open); break;
                case TouchButtonKind.ReloadInsert: r.RaiseReload(ReloadStep.Insert); break;
                case TouchButtonKind.ReloadClose: r.RaiseReload(ReloadStep.Close); break;
            }
        }

        public void OnPointerUp(PointerEventData e) => Release();
        void OnDisable() => Release();

        void Release()
        {
            var r = GameInputRouter.Instance; if (r == null) return;
            if (kind == TouchButtonKind.Throttle) r.SetTouchThrottle(0f);
            else if (kind == TouchButtonKind.Brake) r.SetTouchBrake(0f);
            else if (kind == TouchButtonKind.Handbrake) r.SetTouchHandbrake(false);
        }
    }
}
