using System;
using UnityEngine;
using UnityEngine.UI;

namespace CombatRally
{
    [Serializable]
    public class PromptEntry
    {
        public Image target;
        public Sprite touch, xbox, playStation, keyboard;
    }

    /// Бесшовная смена подсказок (иконок кнопок) и показ/скрытие сенсорного UI.
    public class PromptIconSwitcher : MonoBehaviour
    {
        public PromptEntry[] prompts;
        public GameObject touchControlsRoot;
        GameInputRouter router;

        void Start()
        {
            router = GameInputRouter.Instance;
            if (router == null) return;
            router.OnSchemeChanged += Apply;
            Apply(router.Scheme);
        }

        void OnDestroy() { if (router != null) router.OnSchemeChanged -= Apply; }

        void Apply(ControlScheme s)
        {
            if (touchControlsRoot != null) touchControlsRoot.SetActive(s == ControlScheme.Touch);
            if (prompts == null) return;
            foreach (var p in prompts)
            {
                if (p.target == null) continue;
                Sprite sp = s switch
                {
                    ControlScheme.Touch => p.touch,
                    ControlScheme.Xbox => p.xbox,
                    ControlScheme.PlayStation => p.playStation,
                    _ => p.keyboard
                };
                if (sp != null) p.target.sprite = sp;
            }
        }
    }
}
