using System;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.DualShock;
using UnityEngine.InputSystem.Utilities;

namespace CombatRally
{
    public enum ControlScheme { Touch, Xbox, PlayStation, Keyboard }
    public enum ReloadStep { Open, Insert, Close }

    /// Единая точка ввода: геймпад + сенсор + клавиатура (для отладки).
    /// Действия создаются в коде, внешний .inputactions не нужен.
    [DefaultExecutionOrder(-100)]
    public class GameInputRouter : MonoBehaviour
    {
        public static GameInputRouter Instance { get; private set; }

        [Header("Touch: наклон телефона вместо виртуального руля")]
        public bool useTiltSteering = false;
        public float tiltSensitivity = 1.6f;
        public float tiltDeadzone = 0.05f;

        public float Steer { get; private set; }
        public float Throttle { get; private set; }
        public float Brake { get; private set; }
        public bool Handbrake { get; private set; }
        public Vector2 Aim { get; private set; }
        public ControlScheme Scheme { get; private set; }
        public bool IsGamepad => Scheme == ControlScheme.Xbox || Scheme == ControlScheme.PlayStation;

        public event Action<ControlScheme> OnSchemeChanged;
        public event Action OnFire;
        public event Action<ReloadStep> OnReloadStep;

        // состояние от экранных элементов
        float tSteer, tThrottle, tBrake; bool tHandbrake; Vector2 tAim;
        public void SetTouchSteer(float v) => tSteer = Mathf.Clamp(v, -1f, 1f);
        public void SetTouchThrottle(float v) => tThrottle = Mathf.Clamp01(v);
        public void SetTouchBrake(float v) => tBrake = Mathf.Clamp01(v);
        public void SetTouchHandbrake(bool v) => tHandbrake = v;
        public void SetTouchAim(Vector2 v) => tAim = Vector2.ClampMagnitude(v, 1f);
        public void RaiseFire() => OnFire?.Invoke();
        public void RaiseReload(ReloadStep s) => OnReloadStep?.Invoke(s);

        InputAction steer, throttle, brake, handbrake, aim, fire, rOpen, rInsert, rClose;
        IDisposable anyPress;

        void Awake()
        {
            Instance = this;
            Scheme = Application.isMobilePlatform ? ControlScheme.Touch : ControlScheme.Keyboard;
            BuildActions();
        }

        void BuildActions()
        {
            steer = new InputAction("Steer", InputActionType.Value);
            steer.AddBinding("<Gamepad>/leftStick/x");                       // левый стик
            steer.AddCompositeBinding("1DAxis").With("Negative", "<Keyboard>/a").With("Positive", "<Keyboard>/d");

            throttle = new InputAction("Throttle", InputActionType.Value);
            throttle.AddBinding("<Gamepad>/rightTrigger");                   // RT
            throttle.AddBinding("<Keyboard>/w");

            brake = new InputAction("Brake", InputActionType.Value);
            brake.AddBinding("<Gamepad>/leftTrigger");                       // LT
            brake.AddBinding("<Keyboard>/s");

            handbrake = new InputAction("Handbrake", InputActionType.Button);
            handbrake.AddBinding("<Gamepad>/buttonSouth");                   // A
            handbrake.AddBinding("<Keyboard>/leftShift");

            aim = new InputAction("Aim", InputActionType.Value);
            aim.AddBinding("<Gamepad>/rightStick");                          // правый стик = рука
            aim.AddCompositeBinding("2DVector")
               .With("Up", "<Keyboard>/upArrow").With("Down", "<Keyboard>/downArrow")
               .With("Left", "<Keyboard>/leftArrow").With("Right", "<Keyboard>/rightArrow");

            fire = new InputAction("Fire", InputActionType.Button);
            fire.AddBinding("<Gamepad>/rightShoulder");                      // RB
            fire.AddBinding("<Keyboard>/space");
            fire.AddBinding("<Mouse>/leftButton");

            rOpen = new InputAction("ReloadOpen", InputActionType.Button);
            rOpen.AddBinding("<Gamepad>/leftShoulder");                      // LB
            rOpen.AddBinding("<Keyboard>/q");

            rInsert = new InputAction("ReloadInsert", InputActionType.Button);
            rInsert.AddBinding("<Gamepad>/buttonWest");                      // X
            rInsert.AddBinding("<Keyboard>/e");

            rClose = new InputAction("ReloadClose", InputActionType.Button);
            rClose.AddBinding("<Gamepad>/buttonEast");                       // B
            rClose.AddBinding("<Keyboard>/r");
        }

        void OnEnable()
        {
            fire.performed += OnFirePerformed;
            rOpen.performed += OnOpen; rInsert.performed += OnInsert; rClose.performed += OnClose;
            foreach (var a in new[] { steer, throttle, brake, handbrake, aim, fire, rOpen, rInsert, rClose }) a.Enable();

            if (Accelerometer.current != null) InputSystem.EnableDevice(Accelerometer.current);
            anyPress = InputSystem.onAnyButtonPress.Call(OnAnyButton);
        }

        void OnDisable()
        {
            fire.performed -= OnFirePerformed;
            rOpen.performed -= OnOpen; rInsert.performed -= OnInsert; rClose.performed -= OnClose;
            foreach (var a in new[] { steer, throttle, brake, handbrake, aim, fire, rOpen, rInsert, rClose }) a.Disable();
            anyPress?.Dispose();
        }

        void OnFirePerformed(InputAction.CallbackContext _) => OnFire?.Invoke();
        void OnOpen(InputAction.CallbackContext _) => OnReloadStep?.Invoke(ReloadStep.Open);
        void OnInsert(InputAction.CallbackContext _) => OnReloadStep?.Invoke(ReloadStep.Insert);
        void OnClose(InputAction.CallbackContext _) => OnReloadStep?.Invoke(ReloadStep.Close);

        // Автопереключение схемы по последнему нажатому устройству
        void OnAnyButton(InputControl c)
        {
            var d = c.device;
            ControlScheme s = Scheme;
            if (d is DualShockGamepad) s = ControlScheme.PlayStation;   // DualShock/DualSense
            else if (d is Gamepad) s = ControlScheme.Xbox;
            else if (d is Touchscreen) s = ControlScheme.Touch;
            else if (d is Keyboard || d is Mouse) s = ControlScheme.Keyboard;
            if (s == Scheme) return;
            Scheme = s;
            OnSchemeChanged?.Invoke(s);
        }

        void Update()
        {
            float tilt = 0f;
            if (Scheme == ControlScheme.Touch && useTiltSteering && Accelerometer.current != null)
            {
                float x = Accelerometer.current.acceleration.ReadValue().x;   // экранная ориентация учтена Input System
                tilt = Mathf.Abs(x) < tiltDeadzone ? 0f : x * tiltSensitivity;
            }
            Steer = Mathf.Clamp(steer.ReadValue<float>() + tSteer + tilt, -1f, 1f);
            Throttle = Mathf.Clamp01(throttle.ReadValue<float>() + tThrottle);
            Brake = Mathf.Clamp01(brake.ReadValue<float>() + tBrake);
            Handbrake = handbrake.IsPressed() || tHandbrake;
            Aim = Vector2.ClampMagnitude(aim.ReadValue<Vector2>() + tAim, 1f);
        }
    }
}
