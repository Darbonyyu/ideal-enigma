# Combat Rally (prototype)
First-person combat racing roguelike prototype. Unity 2022.3 LTS + Input System 1.7.

- Open in Unity Hub, then menu **Combat Rally -> Build Prototype Scene** (creates scene, prefabs, touch UI).
- Gamepad / touch / keyboard are handled by `Assets/Scripts/Input/GameInputRouter.cs`.
- CI: `.github/workflows/build-android.yml` (needs secrets UNITY_LICENSE, UNITY_EMAIL, UNITY_PASSWORD or UNITY_SERIAL).
- Keyboard debug: WASD drive, Shift drift, Space fire, Q/E/R open/load/close, arrows aim.
- If Input System doesn't react: Project Settings > Player > Active Input Handling = Input System Package (New).
